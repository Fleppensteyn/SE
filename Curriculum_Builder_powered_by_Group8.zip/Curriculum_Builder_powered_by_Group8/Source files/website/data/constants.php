<?php

//Database related constants
//Used for account levels when logging in.
define("LOGIN_ERROR", -1);
define("LOGIN_BANNED", 0);
define("LOGIN_USER",   1);
define("LOGIN_ADMIN",  2);

?>