<?php
	include("../config.php"); //contains some useful global definitions
	require(DATA_ROOT."core.php");//Include everywhere for session related stuff
	session_start();
?>	

<html>
	<body>
		<h2>&#169; 2014 Genius@Work <br> Powered by Group8</br></h2>
	</body>
</html>